Important note:
To make it run, dont close the EXE after opening it (VERY IMPORTANT).
It is recommended to use and open WantToPlayAGame2.exe.